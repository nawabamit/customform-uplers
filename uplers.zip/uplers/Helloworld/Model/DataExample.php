<?php 
namespace Uplers\Helloworld;
class DataExample extends \Magento\Framework\Model\AbstractModel{
	public function _construct(){
		$this->_init("Uplers\Helloworld\Model\ResourceModel\DataExample");
	}
}
 ?>