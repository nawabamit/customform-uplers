<?php 
namespace Uplers\Helloworld\Model\ResourceModel;
class DataExample extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb{
 public function _construct(){
 $this->_init("uplersblog","id");
 }
}
 ?>