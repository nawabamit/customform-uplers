<?php
 
 namespace Uplers\Helloworld\Setup;
 
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
 
class InstallData implements InstallDataInterface
{
 
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
 
        $tableName = $setup->getTable('uplersblog');
        //Check for the existence of the table
        if ($setup->getConnection()->isTableExists($tableName) == true) {
            $data = [
                [
                    'name' => 'Sean',
                    'surname' => 'Pompeii',
                    'initials' => 's',
                    'age' => '33',
                    'date_of_birth' => date('13/02/1979'),
                ],
                [
                    'name' => 'Sasha Cohen',
                    'surname' => 'Hall',
                    'initials' => 'SC',
                    'age' => '32',
                    'date_of_birth' => '03/06/1980',
                ],

            ];
            foreach ($data as $item) {
                //Insert data
                $setup->getConnection()->insert($tableName, $item);
            }
        }
        $setup->endSetup();
    }
}